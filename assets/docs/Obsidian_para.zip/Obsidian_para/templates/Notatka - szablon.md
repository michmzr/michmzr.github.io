__tagi__: 
__data__: {{date}}

# Tytuł notatki