__tags__: #birds #tanangro 


Ziarnojadek to ptaszek


# Morfologia

Mały ptak o przysadzistym, zaokrąglonym dziobie – u samca w kolorze czarnym, u samicy oliwkowo-brązowym. Samce mają szarą głowę, policzki, grzbiet, skrzydła i ogon. Gardło, pierś, brzuch i podbrzusze w większości kasztanowe, tylko okolice pod skrzydłami szare. Oczy czarne z szarymi powiekami, szare nogi. Czasami samce mają niewielką białą plamkę u nasady dzioba. Samica jest piaskowo-brązowa, z nieco jaśniejszym brzuchem i czarniawymi skrzydłami, z brązowymi obrzeżami [lotek](https://pl.wikipedia.org/wiki/Lotki_(ornitologia) "Lotki (ornitologia)"). Samica jest trudno rozróżnialna od innych gatunków ziarnojadków, jeżeli nie towarzyszy jej samiec[[8]](https://pl.wikipedia.org/wiki/Ziarnojadek_br%C4%85zowobrzuchy#cite_note-ebird-8)[[5]](https://pl.wikipedia.org/wiki/Ziarnojadek_br%C4%85zowobrzuchy#cite_note-HBW_16-5). Ziarnojadek brązowobrzuchy może być mylony z [ziarnojadkiem rdzaworzytnym](https://pl.wikipedia.org/wiki/Ziarnojadek_rdzaworzytny "Ziarnojadek rdzaworzytny") lub [moczarowym](https://pl.wikipedia.org/wiki/Ziarnojadek_moczarowy "Ziarnojadek moczarowy")[[9]](https://pl.wikipedia.org/wiki/Ziarnojadek_br%C4%85zowobrzuchy#cite_note-PeruAves-9). Długość ciała 10 cm, masa ciała średnio 7,8 g[[10]](https://pl.wikipedia.org/wiki/Ziarnojadek_br%C4%85zowobrzuchy#cite_note-botw-10).


https://pl.wikipedia.org/w/index.php?title=Conothraupis&veaction=edit&section=4