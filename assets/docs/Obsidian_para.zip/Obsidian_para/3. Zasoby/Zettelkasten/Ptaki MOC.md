__tags__: #moc #birds


# Ptaki MOC

## Tanangrowate
[[Ziarnojadek]]
[[Conothraupis]]